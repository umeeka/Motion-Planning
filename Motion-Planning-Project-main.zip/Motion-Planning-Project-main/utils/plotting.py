"""
Plotting utilities for motion planning outputs.
"""

from __future__ import annotations

from typing import List, Tuple

import matplotlib.pyplot as plt
import networkx as nx


def plot_road_graph(graph: nx.MultiDiGraph, pos: dict, ax=None) -> None:
    """
    Plot the road graph using NetworkX.
    """
    if ax is None:
        ax = plt.gca()
    nx.draw_networkx_edges(graph, pos=pos, ax=ax, edge_color="lightgray", width=0.5)
    ax.set_aspect("equal", adjustable="box")


def plot_paths(
    graph: nx.MultiDiGraph,
    pos: dict,
    global_path: List[Tuple[float, float]],
    smooth_path: List[Tuple[float, float]],
    trajectory: List[Tuple[float, float]],
    start: Tuple[float, float],
    goal: Tuple[float, float],
) -> None:
    """
    Plot road graph, global path, smoothed path, and tracked trajectory.
    """
    fig, ax = plt.subplots(1, 1, figsize=(10, 8))
    plot_road_graph(graph, pos, ax=ax)

    if global_path:
        gx, gy = zip(*global_path)
        ax.plot(gx, gy, "-b", linewidth=1.5, label="Global Path")

    if smooth_path:
        sx, sy = zip(*smooth_path)
        ax.plot(sx, sy, "-r", linewidth=2.0, label="Smoothed Path")

    if trajectory:
        tx, ty = zip(*trajectory)
        ax.plot(tx, ty, "-g", linewidth=1.5, label="Vehicle Trajectory")

    ax.plot(start[0], start[1], "go", markersize=6, label="Start")
    ax.plot(goal[0], goal[1], "ro", markersize=6, label="Goal")
    ax.set_title("Road Network and Paths")
    ax.legend()
    ax.grid(True)


def plot_curvature_velocity(s: List[float], curvature: List[float], v: List[float]) -> None:
    """
    Plot curvature and velocity profiles.
    """
    fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True)

    axes[0].plot(s, curvature, "-m")
    axes[0].set_ylabel("Curvature [1/m]")
    axes[0].grid(True)

    axes[1].plot(s, v, "-c")
    axes[1].set_ylabel("Velocity [m/s]")
    axes[1].set_xlabel("Path Length [m]")
    axes[1].grid(True)
