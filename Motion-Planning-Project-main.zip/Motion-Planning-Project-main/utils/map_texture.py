"""
Generate a road network texture image from output/map.json for Webots.

Usage:
  python utils/map_texture.py --map output/map.json --out output/map.png --ppm 1.5
"""

from __future__ import annotations

import argparse
import json
import math
from typing import Tuple

import matplotlib.pyplot as plt


def load_map(map_path: str) -> dict:
    with open(map_path, "r", encoding="utf-8") as f:
        return json.load(f)


def compute_bounds(map_data: dict) -> Tuple[float, float, float, float]:
    b = map_data["bounds"]
    return float(b["min_x"]), float(b["max_x"]), float(b["min_y"]), float(b["max_y"])


def render_map(
    map_data: dict,
    out_path: str,
    ppm: float = 1.0,
    max_px: int = 6000,
    line_width_m: float = 2.0,
) -> dict:
    min_x, max_x, min_y, max_y = compute_bounds(map_data)
    width_m = max_x - min_x
    height_m = max_y - min_y

    # Compute pixel size
    width_px = max(1, int(width_m * ppm))
    height_px = max(1, int(height_m * ppm))

    # Clamp to max pixels
    scale = 1.0
    if max_px and max(width_px, height_px) > max_px:
        scale = max_px / float(max(width_px, height_px))
        width_px = max(1, int(width_px * scale))
        height_px = max(1, int(height_px * scale))
        ppm *= scale

    dpi = 100
    fig_w = width_px / dpi
    fig_h = height_px / dpi

    fig, ax = plt.subplots(figsize=(fig_w, fig_h), dpi=dpi)
    fig.patch.set_facecolor("black")
    ax.set_facecolor("black")
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim(min_x, max_x)
    ax.set_ylim(min_y, max_y)
    ax.axis("off")
    plt.subplots_adjust(left=0, right=1, top=1, bottom=0)

    # Convert line width from meters to pixels to points
    line_width_px = max(1.0, line_width_m * ppm)
    line_width_pt = line_width_px * 72.0 / dpi

    # Draw all edges
    for edge in map_data["edges"]:
        coords = edge["geometry"]
        xs = [p[0] for p in coords]
        ys = [p[1] for p in coords]
        ax.plot(xs, ys, color="white", linewidth=line_width_pt, solid_capstyle="round")

    fig.savefig(out_path, dpi=dpi, facecolor=fig.get_facecolor(), pad_inches=0)
    plt.close(fig)

    # Return metadata for Webots placement
    center_x = (min_x + max_x) / 2.0
    center_y = (min_y + max_y) / 2.0
    meta = {
        "width_m": width_m,
        "height_m": height_m,
        "center_x": center_x,
        "center_y": center_y,
        "ppm": ppm,
        "width_px": width_px,
        "height_px": height_px,
        "line_width_m": line_width_m,
        "out_path": out_path,
    }
    return meta


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a Webots map texture from map.json")
    parser.add_argument("--map", required=True, help="Path to map.json")
    parser.add_argument("--out", required=True, help="Output PNG path")
    parser.add_argument("--ppm", type=float, default=1.0, help="Pixels per meter (default 1.0)")
    parser.add_argument("--max-px", type=int, default=6000, help="Max image dimension in pixels")
    parser.add_argument("--line-width", type=float, default=2.0, help="Road line width in meters")
    args = parser.parse_args()

    map_data = load_map(args.map)
    meta = render_map(
        map_data,
        args.out,
        ppm=args.ppm,
        max_px=args.max_px,
        line_width_m=args.line_width,
    )

    print("Map texture saved:")
    print(f"  PNG: {meta['out_path']}")
    print(f"  Size: {meta['width_m']:.2f} m x {meta['height_m']:.2f} m")
    print(f"  Center: ({meta['center_x']:.2f}, {meta['center_y']:.2f})")
    print(f"  Image: {meta['width_px']} x {meta['height_px']} px @ {meta['ppm']:.2f} ppm")


if __name__ == "__main__":
    main()
