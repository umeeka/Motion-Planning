"""
Kinematic bicycle model for vehicle simulation.
"""

from __future__ import annotations

import math
from typing import Tuple


class KinematicBicycle:
    def __init__(self, x: float, y: float, yaw: float, v: float, wheelbase: float):
        self.x = x
        self.y = y
        self.yaw = yaw
        self.v = v
        self.wheelbase = wheelbase

    def state(self) -> Tuple[float, float, float, float]:
        return self.x, self.y, self.yaw, self.v

    def step(self, delta: float, a: float, dt: float) -> None:
        """
        Integrate the kinematic bicycle model.
        """
        # Update velocity with acceleration
        self.v += a * dt

        # Update position and heading
        self.x += self.v * math.cos(self.yaw) * dt
        self.y += self.v * math.sin(self.yaw) * dt
        self.yaw += (self.v / self.wheelbase) * math.tan(delta) * dt
        self.yaw = (self.yaw + math.pi) % (2.0 * math.pi) - math.pi
