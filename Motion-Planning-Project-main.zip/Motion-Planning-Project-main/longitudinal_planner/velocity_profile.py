"""
Longitudinal planner for velocity profiling based on curvature.
"""

from __future__ import annotations

import math
from typing import Dict, List, Tuple

import numpy as np


def compute_curvature(x: List[float], y: List[float]) -> List[float]:
    """
    Compute discrete curvature using a three-point formula.
    """
    n = len(x)
    if n < 3:
        return [0.0 for _ in range(n)]

    curvature = [0.0 for _ in range(n)]
    for i in range(1, n - 1):
        x1, y1 = x[i - 1], y[i - 1]
        x2, y2 = x[i], y[i]
        x3, y3 = x[i + 1], y[i + 1]

        a = math.hypot(x2 - x1, y2 - y1)
        b = math.hypot(x3 - x2, y3 - y2)
        c = math.hypot(x3 - x1, y3 - y1)

        if a < 1e-6 or b < 1e-6 or c < 1e-6:
            curvature[i] = 0.0
            continue

        # Triangle area using cross product
        area = abs((x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1)) / 2.0
        k = 4.0 * area / (a * b * c)
        curvature[i] = k

    # Copy boundary values
    curvature[0] = curvature[1]
    curvature[-1] = curvature[-2]
    return curvature


def cumulative_distance(x: List[float], y: List[float]) -> List[float]:
    s = [0.0]
    for i in range(1, len(x)):
        ds = math.hypot(x[i] - x[i - 1], y[i] - y[i - 1])
        s.append(s[-1] + ds)
    return s


def velocity_profile(
    x: List[float],
    y: List[float],
    v_max: float = 10.0,
    a_lat_max: float = 2.0,
    a_long_max: float = 2.0,
    v_start: float = 0.0,
    v_end: float = 0.0,
) -> Dict[str, List[float]]:
    """
    Generate velocity profile based on curvature and acceleration constraints.
    """
    n = len(x)
    if n == 0:
        return {"s": [], "v": [], "t": [], "curvature": []}

    curvature = compute_curvature(x, y)
    s = cumulative_distance(x, y)

    # Base speed from lateral acceleration constraint
    v = []
    for k in curvature:
        if abs(k) < 1e-6:
            v.append(v_max)
        else:
            v.append(min(v_max, math.sqrt(max(a_lat_max, 1e-6) / abs(k))))

    # Enforce start/end speeds
    v[0] = min(v[0], v_start)
    v[-1] = min(v[-1], v_end)

    # Forward pass (acceleration limit)
    for i in range(1, n):
        ds = s[i] - s[i - 1]
        v[i] = min(v[i], math.sqrt(max(v[i - 1] ** 2 + 2.0 * a_long_max * ds, 0.0)))

    # Backward pass (deceleration limit)
    for i in range(n - 2, -1, -1):
        ds = s[i + 1] - s[i]
        v[i] = min(v[i], math.sqrt(max(v[i + 1] ** 2 + 2.0 * a_long_max * ds, 0.0)))

    # Time parameterization
    t = [0.0]
    for i in range(1, n):
        ds = s[i] - s[i - 1]
        v_avg = max((v[i] + v[i - 1]) * 0.5, 1e-3)
        dt = ds / v_avg
        t.append(t[-1] + dt)

    return {"s": s, "v": v, "t": t, "curvature": curvature}
