"""
Integrated motion planning pipeline (OSMnx -> A* -> Dubins -> velocity -> tracking).

This script:
1) Downloads a road network from OpenStreetMap (OSMnx)
2) Computes a global A* path on the road graph
3) Smooths the path with a Dubins model
4) Generates a velocity profile based on curvature
5) Simulates tracking with Pure Pursuit + PID
6) Saves JSON outputs for Webots
7) Plots results
"""

from __future__ import annotations

import argparse
import json
import os
import time
from typing import List, Tuple

import numpy as np

from env.osm_loader import (
    load_road_network,
    node_position_map,
    pick_start_goal,
    latlon_to_xy,
    nearest_node,
    save_graph_json,
)
from global_planner.astar import astar_search
from local_planner.dubins import dubins_path_from_waypoints
from longitudinal_planner.velocity_profile import velocity_profile
from controller.pure_pursuit import pure_pursuit_control
from controller.pid import PID
from vehicle.bicycle_model import KinematicBicycle
from utils.plotting import plot_paths, plot_curvature_velocity


def build_waypoints_from_nodes(pos: dict, nodes: List) -> List[Tuple[float, float]]:
    return [pos[n] for n in nodes]


def normalize_points(points: List[Tuple[float, float]], offset: Tuple[float, float]) -> List[Tuple[float, float]]:
    ox, oy = offset
    return [(x - ox, y - oy) for x, y in points]


def simulate_tracking(
    path_x: List[float],
    path_y: List[float],
    path_v: List[float],
    wheelbase: float,
    lookahead: float,
    dt: float,
) -> Tuple[List[Tuple[float, float]], float]:
    """
    Simulate tracking with kinematic bicycle + pure pursuit + PID.
    Returns trajectory and RMS tracking error.
    """
    if not path_x:
        return [], 0.0

    # Initialize vehicle at the start
    vehicle = KinematicBicycle(path_x[0], path_y[0], 0.0, 0.0, wheelbase)
    pid = PID(kp=1.0, ki=0.05, kd=0.1, dt=dt, output_limit=3.0)

    traj = []
    errors = []
    target_idx = 0

    for _ in range(20000):
        x, y, yaw, v = vehicle.state()
        delta, target_idx = pure_pursuit_control(
            x, y, yaw, path_x, path_y, lookahead, wheelbase, target_idx
        )
        desired_v = path_v[min(target_idx, len(path_v) - 1)]
        accel = pid.step(desired_v, v)

        # Propagate vehicle state
        vehicle.step(delta, accel, dt)
        traj.append((vehicle.x, vehicle.y))

        # Tracking error (distance to target point)
        dx = path_x[target_idx] - vehicle.x
        dy = path_y[target_idx] - vehicle.y
        errors.append(np.hypot(dx, dy))

        # Stop if close to goal
        if target_idx >= len(path_x) - 1 and np.hypot(path_x[-1] - vehicle.x, path_y[-1] - vehicle.y) < 2.0:
            break

    rms_error = float(np.sqrt(np.mean(np.array(errors) ** 2))) if errors else 0.0
    return traj, rms_error


def save_path_json(
    out_path: str,
    path_x: List[float],
    path_y: List[float],
    path_yaw: List[float],
    path_v: List[float],
    path_t: List[float],
    offset: Tuple[float, float],
) -> None:
    data = {
        "offset": {"x": offset[0], "y": offset[1]},
        "path": [
            {"x": float(x), "y": float(y), "yaw": float(yaw), "v": float(v), "t": float(t)}
            for x, y, yaw, v, t in zip(path_x, path_y, path_yaw, path_v, path_t)
        ],
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def main():
    parser = argparse.ArgumentParser(description="Motion Planning Project (OSMnx + A* + Dubins + Tracking)")
    parser.add_argument("--city", type=str, default="Chennai, India", help="City name for OSMnx")
    parser.add_argument("--start-lat", type=float, default=None, help="Start latitude")
    parser.add_argument("--start-lon", type=float, default=None, help="Start longitude")
    parser.add_argument("--goal-lat", type=float, default=None, help="Goal latitude")
    parser.add_argument("--goal-lon", type=float, default=None, help="Goal longitude")
    parser.add_argument("--min-radius", type=float, default=8.0, help="Minimum turning radius [m]")
    parser.add_argument("--step-size", type=float, default=1.0, help="Dubins sampling step [m]")
    parser.add_argument("--lookahead", type=float, default=8.0, help="Pure Pursuit lookahead [m]")
    parser.add_argument("--v-max", type=float, default=12.0, help="Max velocity [m/s]")
    parser.add_argument("--a-lat", type=float, default=2.0, help="Max lateral acceleration [m/s^2]")
    parser.add_argument("--a-long", type=float, default=2.0, help="Max longitudinal acceleration [m/s^2]")
    parser.add_argument("--wheelbase", type=float, default=2.7, help="Vehicle wheelbase [m]")
    parser.add_argument("--dt", type=float, default=0.1, help="Simulation time step [s]")
    parser.add_argument("--output-dir", type=str, default="output", help="Output directory")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    # 1) ENVIRONMENT CREATION
    print(f"[INFO] Loading road network for: {args.city}")
    graph = load_road_network(args.city, network_type="drive")
    pos = node_position_map(graph)

    # 2) START/GOAL SELECTION
    # Choose start/goal (prefer user-provided lat/lon, else auto-pick)
    start_node = None
    goal_node = None

    if args.start_lat is not None and args.start_lon is not None:
        sx, sy = latlon_to_xy(graph, args.start_lat, args.start_lon)
        start_node = nearest_node(graph, sx, sy)

    if args.goal_lat is not None and args.goal_lon is not None:
        gx, gy = latlon_to_xy(graph, args.goal_lat, args.goal_lon)
        goal_node = nearest_node(graph, gx, gy)

    if start_node is None and goal_node is None:
        start_node, goal_node = pick_start_goal(graph, seed=42)
    elif start_node is None or goal_node is None:
        auto_start, auto_goal = pick_start_goal(graph, seed=99)
        if start_node is None:
            start_node = auto_start
        if goal_node is None:
            goal_node = auto_goal

    # 3) GLOBAL PLANNER (A*)
    print("[INFO] Running A* search on road graph...")
    t0 = time.time()
    path_nodes, path_cost = astar_search(graph, start_node, goal_node, pos)
    planning_time = time.time() - t0
    if not path_nodes:
        raise RuntimeError("A* failed to find a path.")

    global_path = build_waypoints_from_nodes(pos, path_nodes)

    # Normalize coordinates for Webots (start at origin)
    offset = global_path[0]
    global_path_local = normalize_points(global_path, offset)
    pos_local = {n: (p[0] - offset[0], p[1] - offset[1]) for n, p in pos.items()}

    # Save map JSON for Webots
    map_json_path = os.path.join(args.output_dir, "map.json")
    save_graph_json(graph, map_json_path, offset=offset)

    # 4) LOCAL TRAJECTORY SMOOTHING (Dubins)
    print("[INFO] Generating Dubins path...")
    dubins_path = dubins_path_from_waypoints(global_path_local, args.min_radius, args.step_size)

    smooth_path = list(zip(dubins_path.x, dubins_path.y))

    # 5) LONGITUDINAL PLANNING
    print("[INFO] Computing velocity profile...")
    profile = velocity_profile(
        dubins_path.x,
        dubins_path.y,
        v_max=args.v_max,
        a_lat_max=args.a_lat,
        a_long_max=args.a_long,
        v_start=0.0,
        v_end=0.0,
    )

    # 6) CONTROLLER + VEHICLE SIMULATION
    print("[INFO] Simulating tracking...")
    traj, tracking_error = simulate_tracking(
        dubins_path.x,
        dubins_path.y,
        profile["v"],
        args.wheelbase,
        args.lookahead,
        args.dt,
    )

    # 7) SAVE PATH JSON FOR WEBOTS
    print("[INFO] Saving path JSON...")
    path_json_path = os.path.join(args.output_dir, "path.json")
    save_path_json(
        path_json_path,
        dubins_path.x,
        dubins_path.y,
        dubins_path.yaw,
        profile["v"],
        profile["t"],
        offset,
    )

    # 8) METRICS
    path_length = profile["s"][-1] if profile["s"] else 0.0
    max_curvature = max([abs(k) for k in profile["curvature"]]) if profile["curvature"] else 0.0

    print("---- PERFORMANCE METRICS ----")
    print(f"Path length: {path_length:.2f} m")
    print(f"Planning time: {planning_time:.2f} s")
    print(f"Max curvature: {max_curvature:.4f} 1/m")
    print(f"Tracking RMS error: {tracking_error:.2f} m")
    print(f"Path cost (graph length): {path_cost:.2f} m")
    print("-----------------------------")

    # 9) VISUALIZATION
    print("[INFO] Plotting results...")
    plot_paths(
        graph,
        pos_local,
        global_path_local,
        smooth_path,
        traj,
        start=global_path_local[0],
        goal=global_path_local[-1],
    )
    plot_curvature_velocity(profile["s"], profile["curvature"], profile["v"])

    import matplotlib.pyplot as plt

    plt.show()


if __name__ == "__main__":
    main()
