"""
A* global planner for road graphs.

Implements a Node class and A* search with Euclidean heuristic.
"""

from __future__ import annotations

import heapq
import math
from typing import Dict, List, Tuple

import networkx as nx


class Node:
    """
    A* node container with g, h, and f costs.
    """

    def __init__(self, node_id, g: float = math.inf, h: float = 0.0, parent=None):
        self.id = node_id
        self.g = g
        self.h = h
        self.f = g + h
        self.parent = parent


def euclidean(a: Tuple[float, float], b: Tuple[float, float]) -> float:
    """
    Euclidean distance between two 2D points.
    """
    return math.hypot(a[0] - b[0], a[1] - b[1])


def edge_length(graph: nx.MultiDiGraph, u, v, pos: Dict) -> float:
    """
    Extract the shortest edge length between two nodes.
    """
    data = graph.get_edge_data(u, v)
    if data is None:
        return euclidean(pos[u], pos[v])

    # MultiDiGraph: data is a dict of keys -> attributes
    if isinstance(data, dict) and len(data) > 0:
        lengths = []
        for _, attrs in data.items():
            if isinstance(attrs, dict) and "length" in attrs:
                lengths.append(float(attrs["length"]))
        if lengths:
            return min(lengths)

    # Fallback to Euclidean if length is not available
    return euclidean(pos[u], pos[v])


def reconstruct_path(came_from: Dict, current) -> List:
    """
    Reconstruct path from start to goal using parent map.
    """
    path = [current]
    while current in came_from:
        current = came_from[current]
        path.append(current)
    path.reverse()
    return path


def astar_search(
    graph: nx.MultiDiGraph,
    start,
    goal,
    pos: Dict,
) -> Tuple[List, float]:
    """
    Run A* search on a road graph.

    Args:
        graph: OSMnx/NetworkX graph.
        start: start node id.
        goal: goal node id.
        pos: node positions dict {node_id: (x, y)}.

    Returns:
        (path_nodes, path_cost)
    """
    # Initialize open set (priority queue) and maps
    open_heap = []
    came_from: Dict = {}
    g_score: Dict = {start: 0.0}

    start_node = Node(start, g=0.0, h=euclidean(pos[start], pos[goal]), parent=None)
    heapq.heappush(open_heap, (start_node.f, start))

    closed_set = set()

    while open_heap:
        _, current = heapq.heappop(open_heap)

        # Skip stale entries
        if current in closed_set:
            continue

        # Goal check
        if current == goal:
            path = reconstruct_path(came_from, current)
            return path, g_score[current]

        closed_set.add(current)

        # Expand neighbors
        for neighbor in graph.neighbors(current):
            tentative_g = g_score[current] + edge_length(graph, current, neighbor, pos)

            if tentative_g < g_score.get(neighbor, math.inf):
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g

                h = euclidean(pos[neighbor], pos[goal])
                f = tentative_g + h
                heapq.heappush(open_heap, (f, neighbor))

    # If no path found, return empty
    return [], math.inf
