"""
OSMnx-based environment loader and exporter.

This module downloads a drivable road network, converts it to
waypoints, and exports JSON data for Webots use.
"""

from __future__ import annotations

import json
import random
from typing import Dict, List, Tuple

import networkx as nx
import numpy as np
import osmnx as ox
from shapely.geometry import Point


def load_road_network(place_name: str, network_type: str = "drive") -> nx.MultiDiGraph:
    """
    Download and project a drivable road network for a given place name.

    Args:
        place_name: City or region name (e.g., "Chennai, India").
        network_type: OSMnx network type (default "drive").

    Returns:
        A projected (metric) road network graph.
    """
    # Configure OSMnx caching/logging
    ox.settings.use_cache = True
    ox.settings.log_console = False

    # Download and simplify the road network
    graph = ox.graph_from_place(place_name, network_type=network_type, simplify=True)

    # Project to a metric CRS for distance calculations
    graph = ox.project_graph(graph)

    return graph


def node_position_map(graph: nx.MultiDiGraph) -> Dict[int, Tuple[float, float]]:
    """
    Build a node -> (x, y) position map from a projected OSMnx graph.
    """
    pos = {}
    for node_id, data in graph.nodes(data=True):
        pos[node_id] = (float(data["x"]), float(data["y"]))
    return pos


def graph_to_waypoints(graph: nx.MultiDiGraph) -> List[Tuple[float, float]]:
    """
    Convert all graph nodes to a list of waypoints (x, y).
    """
    return list(node_position_map(graph).values())


def latlon_to_xy(graph: nx.MultiDiGraph, lat: float, lon: float) -> Tuple[float, float]:
    """
    Convert latitude/longitude to the graph's projected x/y coordinates.
    """
    # Create a geographic point and project to graph CRS
    point = Point(lon, lat)
    projected_point, _ = ox.projection.project_geometry(point, to_crs=graph.graph["crs"])
    return float(projected_point.x), float(projected_point.y)


def nearest_node(graph: nx.MultiDiGraph, x: float, y: float) -> int:
    """
    Find the nearest node in the graph to a given (x, y).
    """
    return ox.distance.nearest_nodes(graph, X=x, Y=y)


def pick_start_goal(
    graph: nx.MultiDiGraph,
    seed: int = 42,
    sample_size: int = 200,
) -> Tuple[int, int]:
    """
    Pick a start and goal node that are far apart by sampling nodes.
    """
    rng = random.Random(seed)
    nodes = list(graph.nodes())
    if len(nodes) < 2:
        raise ValueError("Graph must contain at least two nodes.")

    # Sample nodes to find a far-apart pair without O(N^2) cost on full graph
    sample = rng.sample(nodes, min(sample_size, len(nodes)))
    pos = node_position_map(graph)

    best_pair = (sample[0], sample[-1])
    best_dist = -1.0
    for i in range(len(sample)):
        for j in range(i + 1, len(sample)):
            xi, yi = pos[sample[i]]
            xj, yj = pos[sample[j]]
            dist = float(np.hypot(xi - xj, yi - yj))
            if dist > best_dist:
                best_dist = dist
                best_pair = (sample[i], sample[j])

    return best_pair


def save_graph_json(
    graph: nx.MultiDiGraph,
    out_path: str,
    offset: Tuple[float, float] | None = None,
) -> None:
    """
    Save graph nodes and edges to JSON for Webots use.
    """
    # Serialize nodes
    nodes = []
    ox0, oy0 = offset if offset is not None else (0.0, 0.0)

    for node_id, data in graph.nodes(data=True):
        nodes.append(
            {
                "id": int(node_id) if isinstance(node_id, (int, np.integer)) else str(node_id),
                "x": float(data["x"]) - ox0,
                "y": float(data["y"]) - oy0,
                "lon": float(data.get("lon", data.get("x"))),
                "lat": float(data.get("lat", data.get("y"))),
            }
        )

    # Serialize edges (including geometry if available)
    edges = []
    for u, v, key, data in graph.edges(keys=True, data=True):
        length = float(data.get("length", 0.0))
        if "geometry" in data:
            coords = [(float(x) - ox0, float(y) - oy0) for x, y in data["geometry"].coords]
        else:
            u_data = graph.nodes[u]
            v_data = graph.nodes[v]
            coords = [
                (float(u_data["x"]) - ox0, float(u_data["y"]) - oy0),
                (float(v_data["x"]) - ox0, float(v_data["y"]) - oy0),
            ]
        edges.append(
            {
                "u": int(u) if isinstance(u, (int, np.integer)) else str(u),
                "v": int(v) if isinstance(v, (int, np.integer)) else str(v),
                "key": int(key) if isinstance(key, (int, np.integer)) else str(key),
                "length": length,
                "geometry": coords,
            }
        )

    xs = [n["x"] for n in nodes]
    ys = [n["y"] for n in nodes]
    bounds = {
        "min_x": float(min(xs)),
        "max_x": float(max(xs)),
        "min_y": float(min(ys)),
        "max_y": float(max(ys)),
    }

    payload = {
        "crs": str(graph.graph.get("crs", "")),
        "bounds": bounds,
        "offset": {"x": ox0, "y": oy0},
        "nodes": nodes,
        "edges": edges,
    }

    # Write JSON to disk
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
