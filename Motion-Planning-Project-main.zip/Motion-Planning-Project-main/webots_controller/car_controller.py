"""
Webots controller for an Ackermann vehicle (no ROS).

This script loads a precomputed path JSON and tracks it using
Pure Pursuit (steering) + PID (speed).
"""

from __future__ import annotations

import json
import math
import os

try:
    from vehicle import Driver
except Exception as exc:
    raise RuntimeError("Webots 'vehicle' module not found. Use a Webots Python controller.") from exc


def find_target_index(x, y, path_x, path_y, lookahead, last_index=0):
    best_dist = float("inf")
    nearest_idx = last_index
    for i in range(last_index, len(path_x)):
        dx = path_x[i] - x
        dy = path_y[i] - y
        d = math.hypot(dx, dy)
        if d < best_dist:
            best_dist = d
            nearest_idx = i

    total_dist = 0.0
    target_idx = nearest_idx
    while target_idx + 1 < len(path_x) and total_dist < lookahead:
        dx = path_x[target_idx + 1] - path_x[target_idx]
        dy = path_y[target_idx + 1] - path_y[target_idx]
        total_dist += math.hypot(dx, dy)
        target_idx += 1
    return target_idx


def pure_pursuit_control(x, y, yaw, path_x, path_y, lookahead, wheelbase, last_index=0):
    target_idx = find_target_index(x, y, path_x, path_y, lookahead, last_index)
    tx = path_x[target_idx]
    ty = path_y[target_idx]
    alpha = math.atan2(ty - y, tx - x) - yaw
    alpha = (alpha + math.pi) % (2.0 * math.pi) - math.pi
    delta = math.atan2(2.0 * wheelbase * math.sin(alpha), lookahead)
    return delta, target_idx


class PID:
    def __init__(self, kp, ki, kd, dt, output_limit=None):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.dt = dt
        self.output_limit = output_limit
        self.integral = 0.0
        self.prev_error = 0.0

    def step(self, target, current):
        error = target - current
        self.integral += error * self.dt
        derivative = (error - self.prev_error) / max(self.dt, 1e-6)
        self.prev_error = error
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        if self.output_limit is not None:
            output = max(-self.output_limit, min(self.output_limit, output))
        return output


def load_path(path_file):
    with open(path_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    path = data["path"]
    path_x = [p["x"] for p in path]
    path_y = [p["y"] for p in path]
    path_v = [p["v"] for p in path]
    return path_x, path_y, path_v


def main():
    driver = Driver()
    timestep = int(driver.getBasicTimeStep())

    # Enable sensors
    gps = driver.getDevice("gps")
    gps.enable(timestep)
    imu = driver.getDevice("imu")
    imu.enable(timestep)

    # Load path (expects path.json in controller directory)
    controller_dir = os.path.dirname(os.path.abspath(__file__))
    path_file = os.path.join(controller_dir, "path.json")
    path_x, path_y, path_v = load_path(path_file)

    # Controller parameters
    wheelbase = 2.7
    lookahead = 8.0
    pid = PID(kp=1.0, ki=0.05, kd=0.1, dt=timestep / 1000.0, output_limit=2.0)

    target_idx = 0

    while driver.step() != -1:
        # Read sensors (Webots ground plane uses x-z)
        gps_vals = gps.getValues()
        x = gps_vals[0]
        y = gps_vals[2]
        roll, pitch, yaw = imu.getRollPitchYaw()

        # Steering control
        delta, target_idx = pure_pursuit_control(
            x, y, yaw, path_x, path_y, lookahead, wheelbase, target_idx
        )

        # Speed control
        desired_speed = path_v[min(target_idx, len(path_v) - 1)]
        current_speed = driver.getCurrentSpeed()
        accel_cmd = pid.step(desired_speed, current_speed)
        speed_cmd = max(0.0, current_speed + accel_cmd * (timestep / 1000.0))

        # Apply commands
        driver.setSteeringAngle(delta)
        driver.setCruisingSpeed(speed_cmd)


if __name__ == "__main__":
    main()
