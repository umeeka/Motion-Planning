"""
PID controller for longitudinal control.
"""

from __future__ import annotations


class PID:
    def __init__(self, kp: float, ki: float, kd: float, dt: float, output_limit: float | None = None):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.dt = dt
        self.output_limit = output_limit

        self.integral = 0.0
        self.prev_error = 0.0

    def reset(self) -> None:
        self.integral = 0.0
        self.prev_error = 0.0

    def step(self, target: float, current: float) -> float:
        error = target - current
        self.integral += error * self.dt
        derivative = (error - self.prev_error) / max(self.dt, 1e-6)
        self.prev_error = error

        output = self.kp * error + self.ki * self.integral + self.kd * derivative

        if self.output_limit is not None:
            output = max(-self.output_limit, min(self.output_limit, output))

        return output
