"""
Pure Pursuit controller for lateral tracking.
"""

from __future__ import annotations

import math
from typing import List, Tuple


def find_target_index(
    x: float,
    y: float,
    path_x: List[float],
    path_y: List[float],
    lookahead: float,
    last_index: int = 0,
) -> int:
    """
    Find the index of the target point at lookahead distance.
    """
    # Find nearest index starting from last_index
    best_dist = float("inf")
    nearest_idx = last_index
    for i in range(last_index, len(path_x)):
        dx = path_x[i] - x
        dy = path_y[i] - y
        d = math.hypot(dx, dy)
        if d < best_dist:
            best_dist = d
            nearest_idx = i

    # Move forward until lookahead distance is reached
    target_idx = nearest_idx
    total_dist = 0.0
    while target_idx + 1 < len(path_x) and total_dist < lookahead:
        dx = path_x[target_idx + 1] - path_x[target_idx]
        dy = path_y[target_idx + 1] - path_y[target_idx]
        total_dist += math.hypot(dx, dy)
        target_idx += 1

    return target_idx


def pure_pursuit_control(
    x: float,
    y: float,
    yaw: float,
    path_x: List[float],
    path_y: List[float],
    lookahead: float,
    wheelbase: float,
    last_index: int = 0,
) -> Tuple[float, int]:
    """
    Compute steering angle using pure pursuit.
    """
    target_idx = find_target_index(x, y, path_x, path_y, lookahead, last_index)
    tx = path_x[target_idx]
    ty = path_y[target_idx]

    # Compute angle to target
    alpha = math.atan2(ty - y, tx - x) - yaw
    alpha = (alpha + math.pi) % (2.0 * math.pi) - math.pi

    # Pure pursuit steering control
    delta = math.atan2(2.0 * wheelbase * math.sin(alpha), lookahead)
    return delta, target_idx
