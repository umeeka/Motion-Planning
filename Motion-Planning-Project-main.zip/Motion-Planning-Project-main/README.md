# Motion Planning Project (Pure Python + Webots)

This project implements an integrated **global + local + longitudinal** motion planning pipeline for a car-like robot using **OSMnx**, **A\***, **Dubins smoothing**, and **Pure Pursuit + PID** tracking.  
It runs on **Windows** and integrates with **Webots** using the built-in Ackermann vehicle.

## Features
- OSMnx road network download (city input)
- A* global planning on road graph
- Dubins path smoothing with minimum turning radius
- Curvature-based velocity profile
- Pure Pursuit steering + PID speed control
- Kinematic bicycle simulation
- Webots controller for Ackermann vehicle
- Visualization and performance metrics

## Folder Structure
```
motion_planning_project/
    env/
        osm_loader.py
    global_planner/
        astar.py
    local_planner/
        dubins.py
    longitudinal_planner/
        velocity_profile.py
    controller/
        pure_pursuit.py
        pid.py
    vehicle/
        bicycle_model.py
    webots_controller/
        car_controller.py
    utils/
        plotting.py
    main.py
    requirements.txt
    README.md
```

## Setup (Windows)
1. Create a Python 3.10+ environment.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

### If OSMnx install fails
Install binary wheels first:
```bash
pip install --only-binary :all: shapely pyproj rtree
pip install osmnx
```

## Run the Pipeline
Example city:
```bash
python main.py --city "Chennai, India"
```

Optional start/goal in lat/lon:
```bash
python main.py --city "Chennai, India" --start-lat 13.0827 --start-lon 80.2707 --goal-lat 13.0051 --goal-lon 80.2575
```

Outputs:
- `output/map.json` (road graph for Webots)
- `output/path.json` (smoothed path + velocity profile)

## Webots Integration (No ROS)

### 1. Create a Webots world
- Open Webots
- Add an **AckermannVehicle** node (e.g., `vehicle`).
- Add **GPS** and **InertialUnit** devices to the vehicle:
  - Name them exactly: `gps`, `imu`

### 2. Attach the controller
- Create a new controller in Webots called `car_controller`
- Copy `webots_controller/car_controller.py` into that controller folder
- Copy `output/path.json` into the same controller folder

### 3. Run Webots
The controller will:
- Read GPS + IMU
- Track the path using Pure Pursuit + PID
- Send steering + speed commands to the vehicle

Note: Webots ground plane uses **x-z** coordinates, so the controller maps `path.y` to Webots `z`.

## Performance Metrics
The script prints:
- Path length
- Planning time
- Maximum curvature
- Tracking RMS error
- Graph path cost

## Notes
- The Dubins path enforces a **minimum turning radius** and smooth heading transitions.
- For additional curvature continuity, you can reduce the Dubins `step_size` or increase the min radius.

## Example City
- Chennai, India
