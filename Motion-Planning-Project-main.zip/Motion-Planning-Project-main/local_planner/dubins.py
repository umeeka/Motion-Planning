"""
Dubins path local planner.

Generates a smooth (x, y, yaw) path between waypoints using a minimum
turning radius constraint.
"""

from __future__ import annotations

import math
from typing import List, Tuple

import numpy as np


class DubinsPath:
    def __init__(self, x: List[float], y: List[float], yaw: List[float], mode: List[str], length: float):
        self.x = x
        self.y = y
        self.yaw = yaw
        self.mode = mode
        self.length = length


def _pi_2_pi(theta: float) -> float:
    while theta > math.pi:
        theta -= 2.0 * math.pi
    while theta < -math.pi:
        theta += 2.0 * math.pi
    return theta


def _mod2pi(theta: float) -> float:
    return theta - 2.0 * math.pi * math.floor(theta / (2.0 * math.pi))


def _LSL(alpha, beta, dist):
    sin_a, sin_b = math.sin(alpha), math.sin(beta)
    cos_a, cos_b = math.cos(alpha), math.cos(beta)
    cos_a_b = math.cos(alpha - beta)
    p = 2 + dist ** 2 - 2 * cos_a_b + 2 * dist * (sin_a - sin_b)
    if p < 0:
        return None
    p = math.sqrt(p)
    denom = dist + sin_a - sin_b
    t = _mod2pi(-alpha + math.atan2(cos_b - cos_a, denom))
    q = _mod2pi(beta - math.atan2(cos_b - cos_a, denom))
    return t, p, q, ["L", "S", "L"]


def _RSR(alpha, beta, dist):
    sin_a, sin_b = math.sin(alpha), math.sin(beta)
    cos_a, cos_b = math.cos(alpha), math.cos(beta)
    cos_a_b = math.cos(alpha - beta)
    p = 2 + dist ** 2 - 2 * cos_a_b + 2 * dist * (sin_b - sin_a)
    if p < 0:
        return None
    p = math.sqrt(p)
    denom = dist - sin_a + sin_b
    t = _mod2pi(alpha - math.atan2(cos_a - cos_b, denom))
    q = _mod2pi(-beta + math.atan2(cos_a - cos_b, denom))
    return t, p, q, ["R", "S", "R"]


def _LSR(alpha, beta, dist):
    sin_a, sin_b = math.sin(alpha), math.sin(beta)
    cos_a, cos_b = math.cos(alpha), math.cos(beta)
    cos_a_b = math.cos(alpha - beta)
    p = -2 + dist ** 2 + 2 * cos_a_b + 2 * dist * (sin_a + sin_b)
    if p < 0:
        return None
    p = math.sqrt(p)
    rec = math.atan2(-cos_a - cos_b, dist + sin_a + sin_b) - math.atan2(-2.0, p)
    t = _mod2pi(-alpha + rec)
    q = _mod2pi(-_mod2pi(beta) + rec)
    return t, p, q, ["L", "S", "R"]


def _RSL(alpha, beta, dist):
    sin_a, sin_b = math.sin(alpha), math.sin(beta)
    cos_a, cos_b = math.cos(alpha), math.cos(beta)
    cos_a_b = math.cos(alpha - beta)
    p = -2 + dist ** 2 + 2 * cos_a_b - 2 * dist * (sin_a + sin_b)
    if p < 0:
        return None
    p = math.sqrt(p)
    rec = math.atan2(cos_a + cos_b, dist - sin_a - sin_b) - math.atan2(2.0, p)
    t = _mod2pi(alpha - rec)
    q = _mod2pi(beta - rec)
    return t, p, q, ["R", "S", "L"]


def _RLR(alpha, beta, dist):
    sin_a, sin_b = math.sin(alpha), math.sin(beta)
    cos_a_b = math.cos(alpha - beta)
    rec = (6.0 - dist ** 2 + 2.0 * cos_a_b + 2.0 * dist * (sin_a - sin_b)) / 8.0
    if abs(rec) > 1.0:
        return None
    p = _mod2pi(2 * math.pi - math.acos(rec))
    t = _mod2pi(alpha - math.atan2(math.cos(alpha) - math.cos(beta), dist - math.sin(alpha) + math.sin(beta)) + p / 2.0)
    q = _mod2pi(alpha - beta - t + p)
    return t, p, q, ["R", "L", "R"]


def _LRL(alpha, beta, dist):
    sin_a, sin_b = math.sin(alpha), math.sin(beta)
    cos_a_b = math.cos(alpha - beta)
    rec = (6.0 - dist ** 2 + 2.0 * cos_a_b + 2.0 * dist * (sin_b - sin_a)) / 8.0
    if abs(rec) > 1.0:
        return None
    p = _mod2pi(2 * math.pi - math.acos(rec))
    t = _mod2pi(-alpha - math.atan2(math.cos(alpha) - math.cos(beta), dist + math.sin(alpha) - math.sin(beta)) + p / 2.0)
    q = _mod2pi(_mod2pi(beta) - alpha - t + p)
    return t, p, q, ["L", "R", "L"]


def _interpolate(ind, l, m, maxc, ox, oy, oyaw, px, py, pyaw):
    if m == "S":
        px[ind] = ox + l / maxc * math.cos(oyaw)
        py[ind] = oy + l / maxc * math.sin(oyaw)
        pyaw[ind] = oyaw
    else:
        ldx = math.sin(l) / maxc
        ldy = (1.0 - math.cos(l)) / maxc
        if m == "R":
            ldy = -ldy

        gdx = math.cos(-oyaw) * ldx + math.sin(-oyaw) * ldy
        gdy = -math.sin(-oyaw) * ldx + math.cos(-oyaw) * ldy
        px[ind] = ox + gdx
        py[ind] = oy + gdy

    if m == "L":
        pyaw[ind] = oyaw + l
    elif m == "R":
        pyaw[ind] = oyaw - l

    return px, py, pyaw


def _generate_local_course(total_length, lengths, mode, maxc, step_size):
    point_num = int(total_length / step_size) + len(lengths) + 3
    px = [0.0 for _ in range(point_num)]
    py = [0.0 for _ in range(point_num)]
    pyaw = [0.0 for _ in range(point_num)]

    ind = 1
    ll = 0.0

    for m, l, i in zip(mode, lengths, range(len(mode))):
        d = step_size if l > 0.0 else -step_size
        ox, oy, oyaw = px[ind], py[ind], pyaw[ind]

        ind -= 1
        if i >= 1 and (lengths[i - 1] * lengths[i]) > 0:
            pd = -d - ll
        else:
            pd = d - ll

        while abs(pd) <= abs(l):
            ind += 1
            px, py, pyaw = _interpolate(ind, pd, m, maxc, ox, oy, oyaw, px, py, pyaw)
            pd += d

        ll = l - pd - d

        ind += 1
        px, py, pyaw = _interpolate(ind, l, m, maxc, ox, oy, oyaw, px, py, pyaw)

    # Trim unused values
    while len(px) >= 1 and abs(px[-1]) < 1e-9 and abs(py[-1]) < 1e-9:
        px.pop()
        py.pop()
        pyaw.pop()

    return px, py, pyaw


def _plan_from_origin(gx, gy, gyaw, curv, step_size):
    d = math.hypot(gx, gy) * curv
    theta = _mod2pi(math.atan2(gy, gx))
    alpha = _mod2pi(-theta)
    beta = _mod2pi(gyaw - theta)

    planners = [_LSL, _RSR, _LSR, _RSL, _RLR, _LRL]

    best = None
    best_cost = float("inf")
    for planner in planners:
        res = planner(alpha, beta, d)
        if res is None:
            continue
        t, p, q, mode = res
        cost = abs(t) + abs(p) + abs(q)
        if cost < best_cost:
            best_cost = cost
            best = (t, p, q, mode)

    if best is None:
        return [], [], [], [], float("inf")

    t, p, q, mode = best
    lengths = [t, p, q]
    x_list, y_list, yaw_list = _generate_local_course(sum(lengths), lengths, mode, curv, step_size)
    return x_list, y_list, yaw_list, mode, best_cost


def calc_dubins_path(
    sx: float,
    sy: float,
    syaw: float,
    gx: float,
    gy: float,
    gyaw: float,
    min_radius: float,
    step_size: float = 1.0,
) -> DubinsPath:
    """
    Compute a Dubins path between two poses.
    """
    curv = 1.0 / max(min_radius, 1e-6)

    # Transform goal into local frame of start
    dx = gx - sx
    dy = gy - sy
    c = math.cos(syaw)
    s = math.sin(syaw)
    lx = c * dx + s * dy
    ly = -s * dx + c * dy
    lyaw = _pi_2_pi(gyaw - syaw)

    # Plan from origin to local goal
    lp_x, lp_y, lp_yaw, mode, total_len = _plan_from_origin(lx, ly, lyaw, curv, step_size)

    # Transform back to global frame
    x_list = []
    y_list = []
    yaw_list = []
    for x, y, yaw in zip(lp_x, lp_y, lp_yaw):
        gxg = c * x - s * y + sx
        gyg = s * x + c * y + sy
        gyaw = _pi_2_pi(yaw + syaw)
        x_list.append(gxg)
        y_list.append(gyg)
        yaw_list.append(gyaw)

    return DubinsPath(x_list, y_list, yaw_list, mode, total_len / curv)


def compute_yaw_from_waypoints(path_xy: List[Tuple[float, float]]) -> List[float]:
    """
    Compute yaw angles from waypoint positions.
    """
    yaws = []
    for i in range(len(path_xy) - 1):
        dx = path_xy[i + 1][0] - path_xy[i][0]
        dy = path_xy[i + 1][1] - path_xy[i][1]
        yaws.append(math.atan2(dy, dx))
    # Repeat last yaw
    if len(yaws) == 0:
        yaws.append(0.0)
    else:
        yaws.append(yaws[-1])
    return yaws


def dubins_path_from_waypoints(
    waypoints: List[Tuple[float, float]],
    min_radius: float,
    step_size: float = 1.0,
) -> DubinsPath:
    """
    Generate a continuous Dubins path through a list of waypoints.
    """
    if len(waypoints) < 2:
        return DubinsPath([], [], [], [], 0.0)

    yaws = compute_yaw_from_waypoints(waypoints)
    out_x, out_y, out_yaw = [], [], []
    total_len = 0.0
    mode = []

    for i in range(len(waypoints) - 1):
        sx, sy = waypoints[i]
        gx, gy = waypoints[i + 1]
        syaw = yaws[i]
        gyaw = yaws[i + 1]
        path = calc_dubins_path(sx, sy, syaw, gx, gy, gyaw, min_radius, step_size)

        # Avoid duplicate start point on concatenation
        if out_x:
            out_x.extend(path.x[1:])
            out_y.extend(path.y[1:])
            out_yaw.extend(path.yaw[1:])
        else:
            out_x.extend(path.x)
            out_y.extend(path.y)
            out_yaw.extend(path.yaw)

        total_len += path.length
        mode.extend(path.mode)

    return DubinsPath(out_x, out_y, out_yaw, mode, total_len)

